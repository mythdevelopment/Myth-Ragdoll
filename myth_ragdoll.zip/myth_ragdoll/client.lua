
local ragdoll = false

RegisterCommand('myth_ragdoll', function()
    if IsPedInAnyVehicle(PlayerPedId(), false) then
        return
    end

    ragdoll = not ragdoll

    if ragdoll then
        CreateThread(function()
            while ragdoll do
                local ped = PlayerPedId()

                if IsPedInAnyVehicle(ped, false) or IsEntityDead(ped) then
                    ragdoll = false
                    break
                end

                SetPedToRagdoll(ped, 1000, 1000, 0, false, false, false)
                Wait(500)
            end
        end)
    end
end, false)

RegisterKeyMapping('myth_ragdoll', 'Myth Ragdoll', 'keyboard', 'U')
