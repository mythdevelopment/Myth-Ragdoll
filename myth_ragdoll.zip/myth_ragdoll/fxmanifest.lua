
fx_version 'cerulean'
game 'gta5'

author 'Myth Development'
description 'Myth Ragdoll keybind U'
version '1.0.0'

client_script 'client.lua'
